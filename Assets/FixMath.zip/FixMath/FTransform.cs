using System;
using ProtoBuf;
using UnityEngine;

namespace LibBase.MathLite.FixMath
{
    [Serializable]
    [ProtoContract]
    public struct FTransform
    {
        [SerializeField][ProtoMember(1)]
        public FVec3 postion;
        [SerializeField][ProtoMember(2)]
        public FVec3 eulerAngles;
    }
}